library(testthat)
library(manSASInvariance)

test_check("manSASInvariance")
