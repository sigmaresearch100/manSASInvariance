# manSASInvariance 0.9.1

## Major changes

* Initial version.
